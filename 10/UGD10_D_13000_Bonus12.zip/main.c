#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define N 5
typedef char string[100];
void sleep(int ms){
	int now = clock();
	while(clock() < now + ms);
}

void initialize(string arrPemilik[], string arrKamar[]);
int searchEmpty(string arr[]);
int isKosong(string nomor, string arrPemilik[], string noKamar[]);
int getIndexKamar(string nomor, string noKamar[] );
int main(int argc, char *argv[]) {
	int menu, i;
	string namaPemilik[N];
	string nomorKamar[N];
	initialize(namaPemilik, nomorKamar);
	string inputNama, inputStr1, inputStr2, tempStr;
	int index, idx1,idx2;
	
	string bonus_A[N];
	string bonus_B[N];
	//13000
	do{
		system("cls");
		puts("\t---=== [ BELI KAMAR APARTEMEN ] ===---");
		puts("[1] BELI KAMAR");
		puts("[2] AVAILABILITY KAMAR");
		puts("[3] PINDAH KAMAR");
		puts("[4] JUAL KAMAR");
		puts("[5] SORT");
		puts("[6] TAMPILKAN SORT");
		puts("[0] EXIT");
		printf("\n>> "); scanf("%d", &menu);
		switch(menu){
		case 1:
			printf("\e[s");
			index = searchEmpty(namaPemilik);
			if(index<0){
				puts("\n\t[!] Apartemen Sudah Penuh [!]");
				break;
			}
			do{
			printf("\nMasukan Nama Pemilik: ");
			fflush(stdin); gets(inputNama);
			if(strcmp(inputNama,"")==0){
				puts("\n\t[!] Nama tidak boleh kosong [!]");
				getch();
				printf("\e[u");
				printf("\e[0J");	
			}
			}while(strcmp(inputNama,"")==0);
			
//			printf("\n\n[%s][%d]", inputNama, index);
			strcpy(namaPemilik[index], inputNama);
			puts("\n\t[*] Berhasil Membeli Kamar [*]");
//			printf("[%s]", namaPemilik[0]);
			break;
		case 2:
			puts("\t[*] AVAILABILITY KAMAR[*]");
			for(i = 0 ; i < N ; i++) if(strcmp(namaPemilik[i], "")!=0)
				printf("\n[%s] PEMILIK : %s",nomorKamar[i], namaPemilik[i]);
			break;
		case 3:
				puts("\n\tPINDAH KAMAR");
				printf("\nMasukan nomor kamar lama : ");
				fflush(stdin); scanf("%s",inputStr1);
				printf("\nMasukan nomor kamar baru : ");
				fflush(stdin); scanf("%s",inputStr2);
				if(getIndexKamar(inputStr1, nomorKamar)<0||getIndexKamar(inputStr2, nomorKamar)<0){
					printf("\n\t[!] Kamar tidak ada [!]");
					break;
				}else 
				if(isKosong(inputStr1,namaPemilik, nomorKamar)){
					puts("\n\t[!] Kamar tidak ada penghuni [!]");
//					getch();
					break;
				}else if(!isKosong(inputStr2,namaPemilik, nomorKamar)){
					puts("\n\t[!] Kamar sudah terisi [!]");
//					getch();
					break;
				}
				idx1 = getIndexKamar(inputStr1, nomorKamar);
				idx2 = getIndexKamar(inputStr2, nomorKamar);
				strcpy(tempStr, namaPemilik[idx1]);
				strcpy(namaPemilik[idx1], namaPemilik[idx2]);
				strcpy(namaPemilik[idx2], tempStr);
				printf("\n\t[*] Berhasil memindahkan [*]");
			break;
		case 4:
			puts("\n\tJUAL KAMAR");
			printf("\nMasukan nomor kamar : ");
			fflush(stdin); scanf("%s",inputStr1);
			index = getIndexKamar(inputStr1, nomorKamar);
				if(index < 0){
					printf("\n\t[!] Kamar tidak ada [!]");
					break;
				}else if(isKosong(inputStr1,namaPemilik, nomorKamar)){
					puts("\n\t[!] Kamar tidak ada penghuni [!]");
					break;
				}
			printf("\n\tApakah anda yakin? [y/N]");
			switch(getch()){
				case 'Y':
				case 'y':
					strcpy(namaPemilik[index], "");
					printf("\n\n\t[*] Berhasil menjual[*]");
					break;
				case 'n':
				case 'N':
				default:
					printf("\n\t[!] Batal menjual [!]");
					break;
			}
			break;
		case 0:
			printf("FARELINO ALEXANDER KIM - 240713000 - D");
			i = 0;
			while(1){
				sprintf(inputNama,"color %d%x", 0, i);
				system(inputNama);
				sleep(500);
				i++;
				i%=16;
			}
		break;
		case 5:
			sort(bonus_A, bonus_B, namaPemilik, nomorKamar);
			printf("\n\t[*] Berhasil Sorting[*]");
			break;
		case 6:
			puts("\t SORTING NAMA");
			for(i = 0 ; i < N ; i++) //if(strcmp(namaPemilik, "")!=0)
				printf("\n[%s] PEMILIK : %s",bonus_B[i], bonus_A[i]);
			break;
		default:
			break;
	}getch();
	}while(menu!=0);
	
	return 0;
}

void initialize(string arrPemilik[], string arrKamar[]){
	int i; 
	for(i = 0; i < N ; i++){
		strcpy(arrPemilik[i],"");
	}
	strcpy(arrKamar[0], "A1");
	strcpy(arrKamar[1], "B3");
	strcpy(arrKamar[2], "C0");
	strcpy(arrKamar[3], "D0");
	strcpy(arrKamar[4], "E0");
}

int searchEmpty(string arr[]){
	int i;
	for(i = 0  ; i < N ; i++){
		if(strcmp(arr[i], "") == 0)return i;
	}
	return -1;
}
int isKosong(string nomor, string arrPemilik[], string noKamar[]){
	int i = 0;
	while(strcmp(noKamar[i], nomor)!=0 && i< N) i++;
	if(strcmp(arrPemilik[i], "")==0) return 1;
	return 0;
}

int getIndexKamar(string nomor, string noKamar[] ){
	int i = 0;
//	printf("\nNOMOR : [%s]", nomor);
	while(i<=N){
		if(strcmp(noKamar[i], nomor)==0)return i;
		i++;
	}
	return -1;
}


int sort(string dest[], string dest2[], string src[], string src2[]){
	int i = 0, j;
	for(i = 0 ; i < N ; i++){
		strcpy(dest[i], src[i]);
		strcpy(dest2[i], src2[i]);
	}
	string temp, temp2;
	for(i = 1 ; i<=N; i++){
		for(j = 1; j<=N;j++){
			if(strcmp(dest[j-1], dest[j])>0){
				strcpy(temp, dest[j-1]);
				strcpy( dest[j-1], dest[j]);
				strcpy(dest[j], temp);
				
				strcpy(temp2, dest2[j-1]);
				strcpy(dest2[j-1], dest2[j]);
				strcpy(dest2[j], temp2);
			}
		}
	}
}
