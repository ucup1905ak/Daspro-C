#include <stdio.h>
#include <stdlib.h>

int isGenap(int a);
int isKuadratSempurna(int a);
long int tenPow(int a);
int brpDigit(int a);
int jumlahkanDigit(int a);
int totalBilAsli(int a);

int main(int argc, char *argv[]) {
	int angka = 000;
	int menu;
	int input;



do{
	system("cls");
	printf("\n\nFarelino Alexander Kim || NPM : 240713000");
	printf("\n\nAngka : %d", angka);
	printf("\n (1) Ubah angka");
	printf("\n (2) Ganjil/Genap");
	printf("\n (3) Bilangan kuadrat sempurna");
	printf("\n (4) Panjang Angka");
	printf("\n (5) Total Bilangan Asli");
	printf("\n (6) Jumlah Digit[BONUS]");
	printf("\n (0) Keluar");
	printf("\n >> "); scanf("%d", &menu);	
	switch(menu){
		case 1:
			printf("\n Masukan angka baru : "); scanf("%d", &input);
			if(input<0){
				printf("\n\n\t[!]Angka tidak Boleh negatif.");
				break;
			}
			angka = input;
			printf("\n\n\t[*] Berhasil Mengubah Angka [*]");
			break;
		case 2:
			printf("\n\n\tAngka %d adalah angka %s", angka, isGenap(angka)?"Genap":"Ganjil");
			break;	
		case 3:
			printf("\n\n\tAngka %d %s", angka , isKuadratSempurna(angka)?
												"ADALAH bilangan kuadrat sempurna":
												"BUKANLAH bilangan kuadrat sempurna");
			break;
		case 4:
			printf("\n\nAngka %d memiliki %d digit.",angka,brpDigit(angka));
			break;
		case 5:
			printf("\n\nTotal bilangan asli dari 1 sampai %d adalah %d", angka, totalBilAsli(angka));
			break;
		case 6:
			printf("\n\nJumlah digit digit angka %d adalah %d",angka,jumlahkanDigit(angka));
			break;
		default:
			break;
	}getch();
}while(menu != 0);
return 0;
}

int isGenap(int a){
	return (a%2 ==0)? 1:0;
}
int isKuadratSempurna(int a){
	int i, count = 0;
	for(i = a; i>0 ;i--){
		if(i * i == a)count++;
	}
	return count;
}
int brpDigit(int a){
	int count;
	for(;a>0;a/=10)count++;
	return count;
}
long int tenPow(int a){
	long int pow = 1;
	for(;a>0;a--)pow*=10;
	return pow;
}
int jumlahkanDigit(int a){
	int temp = 0, i, hasil = 0; 
	int digit = brpDigit(a);
	for (i = digit ; i >0 ; i--){
		temp = a ;
		hasil += temp % 10;
		a /= 10;
	}
	return hasil;
}

int totalBilAsli(int a){
	int hasil=0;
	for(;a>0;a--)hasil += a;
	return hasil;
}
