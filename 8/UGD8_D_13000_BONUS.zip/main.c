#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
typedef char string[100];
void printMenu(int *E, int *HP, bool task, char mision, int lvl);
void cekMenu1(bool *result ,int E, int HP, bool task);
void dispatch(char mission_in,char *mission, int *E, int *HP, bool *task);
void selesaikan(int *lvl,int *E, int *HP, bool *task , char *mission);
void istirahat(int makanan, int *E, int *HP);
void runtimeVariableControl(int *E, int *HP);
void printOption();
void login(bool *loginStatus);
void checkCred(bool *ok,char *username, char *password);
void endTask(int *E, int *HP, bool *task , char *mission);


int main(int argc, char *argv[]) {
	srand(time(NULL));
	//LOGIN
	bool loginStatus;
	//FLOW
	int menu;
	bool cek_1;
	//MAIN STAT
	int E 		= 70;
	int HP		= 85;
	bool task 	= 0;
	char mision = '-' ;
	int lvl		= 45;
	//CASE 1
	char Cinput;
	//CASE 3
	int Vrand;
	
	
	loginStatus = false;
	login(&loginStatus);
	if(!loginStatus) return 0;
	
	
	//MAIN MENU
	do{
		printf("\033[38;2;0;0;0m");
		printf("\033[48;2;188;158;127m");
		
		system("cls");
		printf("\n==== [ PETUALANGAN ] ====\n");
		printMenu(&E, &HP, task, mision, lvl);
		fflush(stdin);
		scanf("%d", &menu);
		switch(menu){
			case 1:
				cekMenu1(&cek_1,E, HP, task);
				if(!cek_1){
					printf("\n\n\t [!] Petualang sedang tidak prima / dalam misi  [!]");
					break;
				}
				
				printf("\nMasukkan tingkat kesulitan misi [A/B/C]: ");
				fflush(stdin);
				scanf("%c",&Cinput);
				switch(Cinput){ //Energi -40 dan Kesehatan -2
					case 'a':
					case 'A':
						if(lvl<50){
							printf("\n\n\t[!] Level petualang tidak cukup untuk misi A [!]");
							break;
						}

						dispatch('A', &mision, &E, &HP, &task);
						break;
					case 'b':
					case 'B': 
						dispatch('B', &mision, &E, &HP, &task);
						break;
					case 'c': 
					case 'C': 
						dispatch('C', &mision, &E, &HP, &task);
						break;
				}
				break;
			case 2:
				if(!task){
					printf("\n\n\t[!] Petualang tidak sedang mengerjakan misi [!]");
					break;
				}
				selesaikan(&lvl, &E, &HP, &task, &mision);
				break;
			case 3:
				if(task){
					printf("\n\n\t[!] Petualang sedang mengerjakan misi [!]");
					break;
				}
				Vrand = rand() % 3;
				istirahat(Vrand, &E, &HP);
				break;

			case 0: //EXIT
				printf("\n\n\tFarelino Alexander Kim");
				printf("\n\t240713000");
				break;
			default:
				printf("\n\n\t[!] Menu Tidak valid [!] ");
				break;
		}getch();
	}while(menu!= 0);
	
	return 0;
}

void printOption(){
	printf("\n\n[1] Kirim ke misi");
	printf("\n[2] Selesaikan Misi");
	printf("\n[3] Istirahat");
	printf("\n[0] Exit");
	printf("\n>> ");
}
void printMenu(int *E, int *HP, bool task, char mision, int lvl){
	runtimeVariableControl(E, HP); // <<<<<<<<<<<<
	printf("\nEnergi    : %d", *E);
	printf("\nKesehatan : %d", *HP);
	printf("\nStatus    : %s", task? "Bertugas": "Istirahat");
	printf("\nMisi      : %c", mision);
	printf("\nLevel     : %d", lvl);
	printOption(); 					// <<<<<<<<<<<<
}
void cekMenu1(bool *result ,int E, int HP, bool task){
	if(E<50 || HP < 30 || task == true)
		*result = false;
		else *result = true;
}

void dispatch(char mission_in,char *mission, int *E, int *HP, bool *task){
	*mission = mission_in;
	*task = 1;
	printf("\n\n[+] Berhasil mengirim Petualang ke misi tingkat %c [+]", mission_in);
}

void selesaikan(int *lvl,int *E, int *HP, bool *task , char *mission){
	printf("\n\n\t[o] Petualang berhasil menyelesaikan misi [o]");
	
	switch(*mission){
		case 'a':
		case 'A':
			*lvl += 5;	
			break;
		case 'b':
		case 'B': 
			*lvl += 3;	
			break;
		case 'c': 
		case 'C': 
			*lvl += 1;	
			break;
	}
	
	endTask(E, HP, task, mission);			 // <<<<<<<<<<<<
}
void endTask(int *E, int *HP, bool *task , char *mission){
	*HP -= 20;
	*E -= 40;
	*task = 0;
	*mission = '-';
}

void istirahat(int makanan, int *E, int *HP){
	switch(makanan){
		case 0: //Roti (energi +30, Kesehatan +20
			*E += 30;
			*HP += 20;
			printf("\n\n\t[+] Petualang memakan ROTI untuk memulihkan tubuhnya [+]");
			break;
		case 1: //Steak (energi +50, Kesehatan +40
			*E += 50;
			*HP += 40;
			printf("\n\n\t[+] Petualang memakan STEAK untuk memulihkan tubuhnya [+]");
			break;
		case 2: //Potion (energi +70, Kesehatan +60)
			*E += 70;
			*HP += 60;
			printf("\n\n\t[+] Petualang meminum POTION untuk memulihkan tubuhnya [+]");
			break;
	}
}

void runtimeVariableControl(int *E, int *HP){
	if(*E<0)*E=0; 
	if(*HP<0)*HP=0; 
	if(*E>100)*E=100; 
	if(*HP>100)*HP=100; 
}
void login(bool *loginStatus){
	string username, password;
	bool ok;
	int kesempatan = 3;
	
	do{ //System LOGIN
		system("cls");
		system("color 07");
		printf("\n\t\t==== [ Login Page ] ====");
		printf("\n\t\t[ Sisa Kesempatan : %d]", kesempatan);
		printf("\nUsername : \n"); printf("\033[38;2;128;128;128mFarel\033[0m\r");
		fflush(stdin); gets(username);
		printf("\nPassword : \n"); printf("\033[38;2;128;128;128m13000\033[0m\r");
		fflush(stdin); gets(password);

		checkCred(&ok,username, password); 		// <<<<<<<<<<<<
		
		if(ok){
			system("color a0");
			printf("\n\t\t[*] Berhasil Login [*]\n\n");
			*loginStatus = true;
			getch();
			break;
		}
			system("color 4f");
			printf("\n\t\t[!] Username/Password salah [!]");
			kesempatan--;
			getch();
	}while(kesempatan!=0);
}

void checkCred(bool *ok,char *username, char *password){
	if(strcmp(username,"Farel")==0&&strcmp(password,"13000")==0)*ok = true;
	else *ok = false;
}
