#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef char string[100];
int main(int argc, char *argv[]) {
	//login & menu
	int menu;
	int statusLogin = 0;
	string username, password;
	
	//General
	int bil_1, bil_2, i, temp;
			//function specific
	int kali = 0; //perkalian
	int bagi = 0, sisa = 0; // pembagian
	int fpb = 0, sub1 = 1, sub2 = 2; // fpb
	
	
	//menu utama
	do{
		bil_1 = 0;
		bil_2 = 0;
		kali = 0;
		bagi = 0;
		fpb = 0;
		sub1 = 0;
		sub2 = 0;
		system("cls");
		printf("=== KALKULATOR SEDERHANA V2.0 ===");
		printf("\n1. Login");
		printf("\n2. Perkalian Loop");
		printf("\n3. Pembagian Loop");
		printf("\n4. FPB");
		printf("\n5. Logout");
		printf("\n0. Exit");
		printf("\nPilihan: "); scanf("%d", &menu);
		switch(menu){
			case 1:
				do{
				system("cls");
				printf("Masukan Username: ");
				fflush(stdin);
				gets(username);
				
				printf("Masukan Password: ");
				fflush(stdin);
				gets(password);
					if(strcmp(username, "Farel") != 0 || strcmp(password, "240713000")!= 0){
						printf("\nLogin gagal! Coba lagi.");
					}
				}while(strcmp(username, "Farel") != 0 || strcmp(password, "240713000")!= 0);
				printf("Login berhasil!");
				statusLogin = 1;
//					TESTING : printf("[%s] [%s]", username, password );
				break;
			case 2:
				//cek login
				if(!statusLogin){
					printf("Anda harus login terlebih dahulu!");
					break;
				}
				printf("Masukkan angka pertama: ");
				scanf("%d", &bil_1);
				
				printf("Masukkan angka kedua: ");
				scanf("%d", &bil_2);
				
				//hitung
				for(i=1;i<=bil_2;i++){
					kali += bil_1;
				}
				
				//hasil
				printf("Hasil: %d", kali);
				bil_1 = 0;
				bil_2 = 0;
				break;
			case 3:
				//cek login
				if(!statusLogin){
					printf("Anda harus login terlebih dahulu!");
					break;
				}
				
				printf("Masukkan angka pertama: ");
				scanf("%d", &bil_1);
				
				printf("Masukkan angka kedua: ");
				scanf("%d", &bil_2);

				i = 0;
				while(bil_1 > 0 && bil_1 - bil_2 >= 0){
//						testing	printf("\n[%d] - [%d] ",bil_1, bil_2);
					i++;
					bil_1 -= bil_2;
//						testing	printf("\n  %d[%d]", i,bil_1);
					bagi = i;
				}
					sisa = bil_1;
				printf("Hasil:%d (Sisa: %d)", bagi, sisa);
				bagi  = 0;
				sisa = 0;
				break;
			case 4:
				//cek login
				if(!statusLogin){
					printf("Anda harus login terlebih dahulu!");
					break;
				}
				printf("Masukkan angka pertama: ");
				scanf("%d", &bil_1);
				
				printf("Masukkan angka kedua: ");
				scanf("%d", &bil_2);
				
				if(bil_2 > bil_1){
					temp = bil_2;
					bil_2 = bil_1;
					bil_1 = temp;
				}
		
				for(i=1 ; i <= bil_1; i++){
					if(bil_1%i == 0)
						sub1 = i;
					if(bil_2%i == 0)
						sub2 = i;
//				testing	printf("\n%d. [%d] [%d]|| [%d] ||[%2d] [%2d]", i,bil_1/i , bil_2/i, (bil_1%i==0&&bil_2%i==0), sub1, sub2);
					if(sub1 == sub2) fpb = sub1;
				}
				printf("FPB : %d",fpb);
				break;
			case 5:
				//cek login
				if(!statusLogin){
					printf("Anda belum login!");
					break;
				}
				statusLogin = 0;
				printf("Logout berhasil!");
				break;
			case 0:
				printf("Terima kasih telah menggunakan program ini!");
				break;
			default:
				printf("Pilihan tidak valid!");
				break;
		}
		printf("\nTekan ENTER untuk melanjutkan...");
		getch();
		
	}while(menu!= 0);

	return 0;
}
