/*
240713000
Farelino Alexander Kim
D
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef char string[100];

int main(int argc, char *argv[]) {
	//Variable
	string username, password; //login
	int opt; //flow-control
	// Jam Masuk / Keluae
	int i_hh, i_mm;
	int o_hh, o_mm;
	int durasi;
	
	// $ Money $
	float h_Bayar;
	float h_Diskon = 0;
	float h_input;
	
	//bonus
	int detik, menit, jam;

	
	//login
	system("cls");
	printf("\t===[LOGIN]===");
	printf("\n\nUsername\t: ");fflush(stdin); gets(username);
	printf("\nPassword\t: ");fflush(stdin); gets(password);
	if( strcmp(username, "Farel")!= 0||strcmp(password, "13000")!= 0){
		printf("\n\t[!] Username & Password Salah [!]");
	}else{
	//Menu
	system("cls");
	printf("\t===[ Warnet Atma ]===\n");	
	printf("\n\nJenis Layanan:");
	printf("\n[1] Reguler (Rp 5000/Jam)");
	printf("\n[2] VIP (8000/Jam)");
	printf("\n[3] Konversi Jam (BONUS)");
	printf("\n[0] Exit");
	printf("\nPilih Menu : "); scanf("%d", &opt);	
	switch(opt){
		case 1:
			printf("\nMasukan jam Masuk (hh:mm)\t: ");
			scanf("%d:%d", &i_hh, &i_mm);
			printf("\nMasukan Durasi (Jam)\t\t: ");
			scanf("%d", &durasi);
			if(durasi<=0){
				printf("\n\t[!] Durasi tidak boleh kurang dari 1 jam [!]");
			}else{	
			printf("\n========================\n");
			// hitung durasi
				o_hh = i_hh + durasi;
				o_mm = i_mm;
			printf("\nJam berakhir main\t\t: %d:%d\n", o_hh, o_mm);

			// hitung harga (Rp 5000 / jam)
				h_Bayar = 5000 * durasi;
				
			printf("\nRincian Harga :");
			printf("\nHarga Rp %.2f", h_Bayar);
			
			// hitung Diskon 
				if(durasi > 7){ //diskon 20%
					h_Diskon = h_Bayar * 0.2;
					h_Bayar *= 0.8;
					printf("\nAnda mendapatkan diskon sebesar Rp %.2f", h_Diskon);
					printf("\nTotal Pembayaran Rp %.2f", h_Bayar);			
				}
			
			
			//Pembayaran
			printf("\nPembayaran Rp "); scanf("%f", &h_input);
			if(h_Bayar>h_input){
				printf("\n\t[!] Uang Tidak Cukup [!]");
			}else{
				printf("\n\t[+] Pembayaran berhasil diperoleh Kembalian Rp %.2f [+]", h_input-h_Bayar);
			}
			}
			//DONE
			
			
			break;
		case 2:
			printf("\nMasukan jam Masuk (hh:mm)\t: ");
			scanf("%d:%d", &i_hh, &i_mm);
			printf("\nMasukan Durasi (Jam)\t\t: ");
			scanf("%d", &durasi);
			if(durasi<=0){
				printf("\n\t[!] Durasi tidak boleh kurang dari 1 jam [!]");
			}else{	
			printf("\n========================\n");
			// hitung durasi
				o_hh = i_hh + durasi;
				o_mm = i_mm;
			printf("\nJam berakhir main\t\t: %d:%d\n", o_hh, o_mm);

			// hitung harga (Rp 8000 / jam)
				h_Bayar = 8000 * durasi;
				
			printf("\nRincian Harga :");
			printf("\nHarga Rp %.2f", h_Bayar);
			
			// hitung Diskon
				if(durasi > 7){ //diskon 20%
					h_Diskon = h_Bayar * 0.2;
					h_Bayar *= 0.8;
					printf("\nAnda mendapatkan diskon sebesar Rp %.2f", h_Diskon);
					printf("\nTotal Pembayaran Rp %.2f", h_Bayar);			
				}
			
			
			//Pembayaran
			printf("\nPembayaran Rp "); scanf("%f", &h_input);
			if(h_Bayar>h_input){
				printf("\n\t[!] Uang Tidak Cukup [!]");
			}else{
				printf("\n\t[+] Pembayaran berhasil diperoleh Kembalian Rp %.2f [+]", h_input-h_Bayar);
			}
			}
			//DONE
			
			break;
			
		//BONUS
		case 3:
			system("cls");
			printf("\n->Inputan jumlah detik : "); scanf("%d", &detik);
			
			if(detik<1){
				printf("\n\t[!] Detik tidak boleh kurang dari 1 [!]");
			}else{	
				jam = detik / 3600;
				menit = (detik % 3600) / 60 ;
				detik = detik % 3600 % 60;
					//testing
//					printf("[%d] [%d] [%d]", jam, menit, detik);
				printf("\nHasil Konversi :");
				printf("\n%d Jam sisa %d menit dan %d detik", jam, menit, detik);
			}
			//DONE
			
			break;
		case 0:
			printf("\n\n[*] Program Selesai ....");
			printf("\nFarelino Alexander Kim | 240713000 | D");
			break;
		default:
			printf("\n\t[!] Input menu Salah!! [!]");
			break;		
	}	
	}
	
	
	return 0;
}
