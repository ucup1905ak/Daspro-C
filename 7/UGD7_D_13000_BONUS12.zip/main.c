#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef char string[100];

void Menu();  //naive
void KodeUnik(long long int * kode); // semi naive output
void Faktorial(long long int * hasil , int value); //nett
void Kelipatan(float * hasil, float *x, float *y); //semi naive output
void Total(long long int kode, long long int faktorial, float kelipatan); //semi naive input
void Reset(int *menu_1,int *menu_2,int *menu_3,int *menu_4,long long int * kode,long long int * faktorial,float * hasil, float *a, float *b );
void print(int tinggi, int lebar);
/*

				if(menu_1){
					printf("\n\n\t[!] ");
					break;
				}

*/

int main(int argc, char *argv[]) {
	srand(time(NULL));
	
	
	//flow 
	char menu;
	int i;
	
	//check menu
	int menu_1 = 0;
	int menu_2 = 0;
	int menu_3 = 0;
	int menu_4 = 0;
	
	
	//menu 6
	int randomValue;
		//check ascii
		/*
		for(i = 0 ; i < 256; i++)
			printf("%d >> [ %c ]\n",i,i);
		*/
		
		//bonus
		int lebar,tinggi;
	//menu 1
	long long int kode;
	//menu 2
	long long int hasil;
	int angkaFaktorial;
	
	//menu 3
	float HasilKelipatan;
	float a,b;
	do{
		system("cls");
		Menu();
		menu = getch();
		switch(menu){
			case 49: //1 Kode Unik
				if(menu_1){
					printf("\n\n\t[!] Menu tidak bisa diakses lagi.");
					break;
				}
				system("cls");
				printf("\n\n\t--==[ Kode Unik ]==--\n");
				KodeUnik(&kode);
				printf("\nKode Unik       :%lld", kode);
				
				menu_1 = 1;
				break;
			case 50: // 2 Faktorial
				if(menu_2){
					printf("\n\n\t[!] Menu tidak bisa diakses lagi.");
					break;
				}
				if(!menu_1){
					printf("\n\n\t[!] Akses Menu Sebelumnya terlebih dahulu");
					break;
				}
				system("cls");
				printf("\n\t--==[ Faktorial ]==--\n");
				printf("\nmasukan Angka\t: ");
				scanf("%d", &angkaFaktorial);
				Faktorial(&hasil, angkaFaktorial);
				printf("\nHasil dari %d! adalah : %lld",angkaFaktorial, hasil);
				menu_2 = 1;
				break;
			case 51://3 Kelipatan
				if(menu_3){
					printf("\n\n\t[!] Menu tidak bisa diakses lagi.");
					break;
				}
				if(!menu_2){
					printf("\n\n\t[!] Akses Menu Sebelumnya terlebih dahulu");
					break;
				}
				system("cls");
				printf("\n\n\t--==[ Kelipatan ]==--\n");
				Kelipatan(&HasilKelipatan, &a , &b);
				printf("\nHasil dari %.2f Kelipatan ke-%.2f adalah %.2f", a, b, HasilKelipatan);
				menu_3 = 1;
				break;
			case 52://4 Total
				if(menu_4){
					printf("\n\n\t[!] Menu tidak bisa diakses lagi.");
					break;
				}
				if(!menu_3){
					printf("\n\n\t[!] Akses Menu Sebelumnya terlebih dahulu");
					break;
				}
				system("cls");
				printf("\n\n\t--==[ Total ]==--\n");
				Total(kode, hasil, HasilKelipatan);
				menu_4 = 1;
				break;
			case 53://5 Reset
				if(!menu_1&&menu_2&&!menu_3&&!menu_4){
					printf("\n\n\t[!] Isi Data Terlebih Dahulu");
					break;
				}
				system("cls");
				printf("\n\n\t--==[ Reset Data ]==--\n");
				Reset(&menu_1, &menu_2, &menu_3, &menu_4, &kode, &hasil ,&HasilKelipatan, &a, &b);
				
				break;
			case 54: //6 [BONUSSS]
			printf("\n\nMasukan Lebar\t: ");
				scanf("%d", &lebar);
			printf("\n\nMasukan Tinggi\t: ");
				scanf("%d", &tinggi);
				print(tinggi, lebar);
			break;
			case 27:
				printf("\n\n\tFarelino Alexander | 240713000 | D");
				printf("\n\t~Prosedur Itu Mudah");
				randomValue = rand() % 3;
				if( randomValue == 0)
					printf("\n\n\t\t[~] God Bless You [~]" );
				else if(randomValue == 1)
					printf("\n\n\t\t[~] Cya [~]" );
				else if(randomValue == 2)
					printf("\n\n\t\t[~] Xie-Xie [~]" );
				/*
				Farelino Alexander | 240713000 | D
       					 ~Prosedur Itu Mudah

                [~] Cya [~] [~] Xie-Xie [~] [~] God Bless You [~]
				*/
				break;
			default:
				printf("\n\n\t[!] Menu tidak valid [!]");
				break;
		}getch();
		printf("\n\n\tPress any key to continue...");
	}while(menu != 27);
	return 0;
}


void Menu(){
puts("\t\t---===[ Pros Type 1 ]===---\n");
puts("[1] Kode Unik");
puts("[2] Faktorial");
puts("[3] Kelipatan");
puts("[4] Total");
puts("[5] Reset");
puts("[6] Re Persegi Panjang (BONUS)");
puts("[ESC] Exit");
puts(">>> ");
}


void KodeUnik(long long int * kode){
	long long int npm, a;
	int i,j,pow = 1;
	long long int temp = 0;
	do {
		printf("\nMasukan NPM\t: ");
		scanf("%lld", &npm);
		if(npm / 100000000 > 10 || npm % 100000000 == 0 || npm / 100000000 == 0){
			printf("\n\n\t[!] Wajib 9 Digit [!]");
			getch();
		}
	} while(npm / 100000000 > 10 || npm % 100000000 == 0 || npm / 100000000 == 0);

	a = npm /10000;
	*kode = a * 10000;
	
//	printf("\n%lld\n", a);
	for(i = 5 ; i > 0; i--){
		pow = 1;
		for(j = (i-1);j>0;j--)pow *= 10;
		
		temp += a / pow;
		a = a % pow;
//		printf("\n%d, %lld, %d\n", temp, a, pow);
	}
	*kode += temp;
//	printf("%lld", *kode);
}
void Faktorial(long long int * hasil , int value){
	int i;
	long long int temp = 1;
	for (i = value ; i > 0 ; i--){
		temp *= i;
	}
	*hasil = temp;
//	printf("temp = %lld", temp);
}

void Kelipatan(float * hasil, float *x, float *y){
	float a,b,temp = 0;
	int i;
	do{
		
	printf("\nMasukan Angka\t: ");
	scanf("%f", &a);
	printf("\nMasukan Banyak Kelipatan\t: ");
	scanf("%f", &b);
	if(a<1 ||b<1){
		printf("\n\n\tTidak boleh kecil dari 1");
	}
	}while(a<1 ||b<1);
	*x = a;
	*y = b;
	
	printf("\nKelipatan %.2f adalah ", a);
	for(i = 1; i <= b; i++)
	{
			temp+=a;
			printf("%.2f ", temp);
	}
	*hasil = temp;
	printf("\n");
}

void Total(long long int kode, long long int faktorial, float kelipatan){
	printf("\nKode Unik       : %lld", kode);
	printf("\nHasil dari %lld ditambah %.2f adalah %.2f", faktorial, kelipatan, faktorial + kelipatan);
}
void Reset(int *menu_1,int *menu_2,int *menu_3,int *menu_4,long long int * kode,long long int * faktorial,float * hasil, float *a, float *b ){
	char confirm;
	printf("\n\n\t[!] Apakah Anda Yakin Ingin Melakukan Reset (Y/N) :");
	fflush(stdin);
	confirm = getchar();
	if(confirm == 'Y' || confirm == 'y'){
			*menu_1 =0;
	*menu_2 =0;
	*menu_3 =0;
	*menu_4 =0;
	*kode = 0;
	*faktorial = 0;
	*hasil = 0;
	*a = 0;
	*b = 0;
	printf("\n\n\t[+] Berhasil menghapus data");

	}else
	 {
	 printf("\n\n\t[!]Gagal Menghapus Data");
	 }
}

void print(int tinggi, int lebar){
	int i;
		for(i = 0 ; i <lebar ; i++)
		printf("* ");
		printf("\n");
	
	if(tinggi>0)print((tinggi-1), lebar);
}
